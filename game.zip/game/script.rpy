﻿# Bem vindo ao script do TCC :D

# Personagens
define p = Character("Protagonista", color="#c8ffc8")
define r = Character("Ronaldo", color="#c8c8ff")
define n = Character("??????", color="#FFFFFF")

# Sprites
image ronaldo feliz = "images/ronaldo_feliz.png"
image ronaldo puto = "images/ronaldo_puto.png"
image ronaldo incomodado = "images/ronaldo_incomodado.png"

# Variáveis para exploração
default visitou_esquerda = False
default visitou_frente = False

# o jogo começa aqui
label start:

    scene trans with fade

    n "(Foi a uma semana...)"
    n "(Eu acordei atrasado e fui correndo ao local da prova)"

    scene out with fade

    p "Bom, aqui estou eu."
    p "Provavelmente o dia mais infernal da minha vida"
    p "O ENEM!!!!! O MAIOR TERROR DE TODOS OS ETECANOS!!!"

    p "Merda, esqueci minha caneta azul..."
    p "Bom, vai com a preta mesmo."

    p "MEU DEUS OLHA A HORA"
    p "Melhor eu ir antes que eu fique pra fora"

    scene trans with fade

    n "(Entro na escola e vejo um monte de gente correndo)"

    scene bg_tela2 with fade

    p "MEU PAI AMADO DO CÉU,TEM TANTA GENTE ASSIM???"

    p "PARECE ATÉ O SHOW DO BAD BUNNY MEU DEUS 😭"
    
    p "(melhor eu ir para a sala logo...)"

    n "(um tempo depois...)"

    p "(aonde fica a sala?)"

    menu:
        "Perguntar para alguém":
            jump perguntar_ronaldo

        "Procurar sozinho":
            jump exploracao


# CAMINHO RONALDO
label perguntar_ronaldo:

    show ronaldo feliz at center with fade

    p "Com licença, você sabe onde fica a sala 6?"

    r "Cara... eu também tô perdido."

    r "Quer procurar a sala comigo?"

    menu:
        "Aceitar ajuda":
            jump aceitar_ajuda

        "Negar ajuda":
            jump exploracao

        "Ser grosso":
            jump ser_grosso


label aceitar_ajuda:

    p "Claro, melhor do que procurar sozinho."

    r "Bora então."

    scene classe with fade

    p "Oia, achamos a sala"

    show ronaldo feliz

    r "Eu disse que a genti ia achar mané!!"
    r "Boa sorte na prova bobão!"

    p "(Mas que arromb..)"

    jump final_beta


label ser_grosso:

    p "Sai da frente, vou melhor sozinho."

    show ronaldo puto

    r "Ô SEU ARROMBADO!"

    hide ronaldo

    p "(acho que exagerei...)"

    jump exploracao


# SISTEMA DE EXPLORAÇÃO
label exploracao:
    scene bg_tela2 with fade
    p "(Essa escola é enorme...)"

    menu:

        "Ir para a esquerda" if not visitou_esquerda:
            $ visitou_esquerda = True
            jump esquerda

        "Ir para frente" if not visitou_frente:
            $ visitou_frente = True
            jump frente

        "Ir para a direita":
            jump direita


# ESQUERDA
label esquerda:

    scene trans

    p "(tem uma sala aqui...)"

    n "(voce escuta uns barulhos abafados vindo da sala)"

    p "(vou abrir a porta...)"

    n "*porta abrindo*"
    scene abraço with fade
    p "QUE PORRA É ESSA???"

    n "OQUE VOCÊ TÁ FAZENDO AQUI??"

    p "FOI MAL!!!"

    p "(melhor eu sair daqui...)"

    # Agora verifica DEPOIS da cena
    if visitou_frente:
        jump final_atraso

    jump exploracao


# FRENTE
label frente:

    scene bebedouro with fade

    p "(um bebedouro...)"

    p "(não era isso que eu estava procurando...)"

    p "(melhor continuar procurando...)"

    # Agora verifica DEPOIS da cena
    if visitou_esquerda:
        jump final_atraso

    jump exploracao


# DIREITA
label direita:

    p "(achei duas salas...)"

    menu:
        "Entrar na sala 6":
            jump sala_certa

        "Entrar na sala 8":
            jump sala_errada


label sala_certa:

    scene classe with fade

    p "(FINALMENTE achei a sala!)"

    jump final_beta


label sala_errada:

    scene classe

    p "(essa não é minha sala...)"

    p "(MERDA! perdi muito tempo!)"

    p "(acho que me atrasei para a prova...)"

    n "O QUE VOCÊ TÁ FAZENDO AQUI??"
    
    n "A PROVA JÁ COMEÇOU!!"

    p "PUTA QUE PARIUUUUUUUUUU"

    jump final_atraso_ruim


# FINAL NORMAL
label final_beta:

    scene bg_mesa with fade

    p "A pior parte vem agora..."

    p "Pelo menos achei a sala a tempo."

    n "Fim da beta."

    return


label final_atraso_ruim:

    scene out with fade

    p "VAI TOMAR NO CU, eu realmente perdi a prova por causa disso"

    p "NÃO TINHA NEM A MARCAÇÃO DAS SALAS, COMO EU VOU SABER ONDE FICA A MINHA SALA??"

    p "Maldito sistema de ensino brasileiro..."

    p "FINAL RUIM — ATRASO"

    return

# FINAL ATRASO
label final_atraso:

    scene out with fade

    p "Eu não acredito que eu me atrasei para a prova..."

    p "(vejo um morador de rua)"

    n "Ow rapaz, senta aqui do meu lado"

    menu:
        "Falar com o morador de rua":
            jump falar_morador

        "Ignorar o morador de rua":
            jump ignorar_morador


label falar_morador:

    p "Ah...beleza"

    p "(sento ao lado do morador de rua)"

    n "Você também fez faculdade de engenharia?"

    n "Porque eu fiz, e olha onde eu to agora :D"

    p "(Pobre rapaz...eu deveria oferecer um pouco de dinheiro pra ele...)"

    menu:
        "Oferecer dinheiro":
            jump oferecer_dinheiro

        "Não oferecer dinheiro":
            jump nao_oferecer_dinheiro


label oferecer_dinheiro:

    p "Aqui, é pouco mas vai te ajudar"

    p "(Abro minha carteira e dou uma olhada....)"

    p "QUE MINHA CARTEIRA TÁ VAZIA??"

    n "Pobre garoto, toma um trocado pro onibus"

    p"(Fico envergonhado mas aceito o dinheiro...)"

    p "É.... muito obrigado"

    p "(Saio envergonhado...)"

    n "(FINAL - CARIDADE?)"

    return

label nao_oferecer_dinheiro:

    p "(decido não oferecer dinheiro para o morador de rua...)"

    n "Você se atrasou para o ENEM!! Mas fez um amigo mendigo "

    n "FINAL RUIM — ATRASO"

    return

label ignorar_morador:

    p "Não, obrigado"

    p "(ignoro o morador de rua e fico ali chorando sozinho...)"

    n "FINAL RUIM — ATRASO"

    return